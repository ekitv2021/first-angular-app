import {Component} from "@angular/core"

@Component({    
    selector:'app',
    template: 
            `
            <h1>Welcome</h1>
            <h3>App Component</h3>
            <p>Multiline string</p>
            <p>{{title}} - {{num}} - {{56+56}}</p>
            <p *ngFor="let c of colors">
                {{c}}
            </p>
            <p>{{marks[0]}} {{marks[1]}} {{marks[2]}} {{marks[3]}} {{marks[4]}} {{marks[5]}}</p>
            `,
    styles: [
        `h1{
            color:blue;
        }
        h3{
            color:red;
        }`
    ]
})
export class AppComponent{
    //to define the variable, no need to use var, let or const
    //here datatype is assigned implicitly
    title = "this is my first app"; 
    num = 89 
    
    //here datatype is assigned explicitly
    // title:any = "string";

    //[] are used to define array,
    //collection of multiple referred using same variable name
    colors = ["red","green","blue","yellow","purple","pink","orange"];

    marks: number[] = [56,34,65,46,5,23];
}